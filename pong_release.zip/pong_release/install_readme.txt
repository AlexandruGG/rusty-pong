Hello and thank you for interest in Rusty Pong!

Requirements:
- macOS, linux (requires compilation, see README.md)
- Simple DirectMedia Layer (SDL 2.0) installed on the system - https://www.libsdl.org/index.php

Steps:
1. run ./install for a smooth setup process
2. run ./pong to play the game
